import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import axios from 'axios';
import Geolocation from '@react-native-community/geolocation';

const PointofInterest = () => {
  const [places, setPlaces] = useState([]);
  const [loading, setLoading] = useState(true);
  const [location, setLocation] = useState(null);
  const [ViewMore, setViewMore] = useState(false);

  useEffect(() => {
    Geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
       // setLocation({ "37.7749", "-122.4194" });
        fetchPlaces("27.149994", "79.499901");
      },
      (error) => console.error('Error getting location', error),
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
    );
  }, []);

  const fetchPlaces = async (latitude, longitude) => {

    try {
      const response = await axios.get('https://maps.googleapis.com/maps/api/place/nearbysearch/json', {
        params: {
          location: `${latitude},${longitude}`,
          radius: 2000, // Search radius in meters
         // type: 'school', // Type of POIs to search for  
         // type: 'university',
          //type: 'hospital',
          //type: 'restaurant',
          //type: 'bus_station|train_station',
          
          type: 'bank|atm',
          //bank|atm  type=school&type=university
          key: 'AIzaSyDScJ03PP_dCxbRtighRoi256jTXGvJ1Dw', // Your API Key
        },
      });

      const placesWithDistance = response.data.results.map((place) => {
        const distance = calculateDistance(latitude, longitude, place.geometry.location.lat, place.geometry.location.lng);
        console.log (distance)
        return { ...place, distance };
      });
      console.log (placesWithDistance)
     // setPlaces(placesWithDistance);
      setPlaces(placesWithDistance.slice(0, 5))
    } catch (error) {
      console.error('Error fetching places:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const toRad = (value) => (value * Math.PI) / 180;
    const R = 6371; // Radius of the Earth in km
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c * 1000; // Convert to meters
  };



  return (
    <View style={styles.container}>
      <Text style={styles.title}>Nearby Restaurants with Distance</Text>
      <FlatList
        data={places}
        keyExtractor={(item) => item.place_id}
        renderItem={({ item }) => (
          <>
          <View style={styles.item}>
            <Text style={styles.name}>{item.name}</Text>
            {/* <Text style={styles.address}>{item.vicinity}</Text> */}
            <Text style={styles.distance}>
              {/* {item?.distance.toString().split('.')[0]}
               {item?.distance.toString().substring(0, 1)}  */}
               {(item?.distance.toFixed(2)/1000).toString().substring(0, 3)}
 km</Text>
          </View>
          <Text>
      {ViewMore ? "show less" : "  read more"}
      </Text>
          </>

        )}
      />
      <Text>
      {ViewMore ? "show less" : "  read more"}
      </Text>
       
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
 
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  item: {
    flexDirection:'row',
    justifyContent:'space-between',
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  name: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  address: {
    fontSize: 14,
    color: '#555',
  },
  distance: {
    fontSize: 14,
    color: '#888',
  },
});

export default PointofInterest;
