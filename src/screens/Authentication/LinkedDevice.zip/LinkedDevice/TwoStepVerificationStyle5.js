import { StyleSheet } from "react-native";
import { _COLORS,FONTFAMILY } from "../../../Themes";
export const TwoStepVerificationStyle5 = StyleSheet.create({
  Mainview: {
    flex: 1,
    backgroundColor: _COLORS.Kodie_WhiteColor,
  },
  container:{
    marginHorizontal:25,
    marginTop:20 
  },
  img:{
   alignItems:"center",
   marginTop:40
},
  text:{
    marginTop:60,
    alignItems:'center',
    fontSize:14,
    lineHeight:20,
    padding:15,
    textAlign:"center"
  },
  text1:{
    fontSize:21
  },
  Button:{
    marginTop: 45
  },

});
